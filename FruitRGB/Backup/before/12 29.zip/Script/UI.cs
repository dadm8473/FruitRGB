﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UI : MonoBehaviour
{
    public GameObject stop;
    public GameObject gameOver;

    public Image Timer;

    private void Update()
    {
        Timer.fillAmount -= 0.05f * Time.deltaTime;

        if(Timer.fillAmount <= 0)
        {
            gameOver.SetActive(true);
            Time.timeScale = 0;
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            stop.SetActive(true);
            Time.timeScale = 0;
        }
    }

    public void Continue()
    {
        Time.timeScale = 1;
        if (stop)
            stop.SetActive(false);
    }

    public void Replay()
    {
        Timer.fillAmount = 1;
        Time.timeScale = 1;
        SceneManager.LoadScene("Game");
    }

    public void Leave()
    {
        Timer.fillAmount = 1;
        Time.timeScale = 1;
        SceneManager.LoadScene("Main");
        if(stop)
            stop.SetActive(false);
    }
}
