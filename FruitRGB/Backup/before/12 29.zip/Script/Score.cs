﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Score : MonoBehaviour
{
    //Renderer rend;
    Text text;

    public float ScoreDelay = 0.5f;
    void Start()
    {
        //rend = GetComponent<Renderer>();
        text = GetComponent<Text>();
        StartCoroutine("DisplayScore");
    }

    void Update()
    {
        Vector3 pos = transform.position;
        pos.y += 0.01f;
        transform.position = pos;
    }

    IEnumerator DisplayScore()
    {
        yield return new WaitForSeconds(ScoreDelay);

        for (float a = 1; a >= 0; a -= 0.05f)
        {
            //transform.guiText.material.color = new Vector4(1, 1, 1, a);
            //rend.material.color = new Vector4(1, 1, 1, a);
            //GUI.color = new Vector4(1, 1, 1, a);
            text.color = new Vector4(1, 1, 1, a);
            yield return new WaitForFixedUpdate();
        }

        Destroy(gameObject);
    }
}