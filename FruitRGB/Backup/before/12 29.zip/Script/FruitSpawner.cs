﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitSpawner : MonoBehaviour {

    public GameObject[] fruitPrefab;
    public Transform[] spawnPoints;

    float minDelay = 0.3f;
    float maxDelay = 1.5f;

	// Use this for initialization
	void Start ()
    {
        StartCoroutine(SpawnFruits());
	}

    IEnumerator SpawnFruits()
    {
        while(true)
        {
            float delay = Random.Range(minDelay, maxDelay);
            yield return new WaitForSeconds(delay);

            // 과일 소환
            int spawnIndex = Random.Range(0, spawnPoints.Length);
            Transform spawnPoint = spawnPoints[spawnIndex];

            int fruitIndex = Random.Range(0, fruitPrefab.Length);
            GameObject spawnedFruit = Instantiate(fruitPrefab[fruitIndex], spawnPoint.position, spawnPoint.rotation);
            Destroy(spawnedFruit, 3f);
        }
    }
}
