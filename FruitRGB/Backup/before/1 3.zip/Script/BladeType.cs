﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BladeType : MonoBehaviour {
    
    // 패널을 눌렀을 때 블레이드 타일 변경

    public void RO_Panel()
    {
        //Debug.Log("RO");
        Blade.getInstance().type = 1;
    }

    public void RD_Panel()
    {
        //Debug.Log("R_");
        Blade.getInstance().type = 2;
    }

    public void LO_Panel()
    {
        //Debug.Log("LO");
        Blade.getInstance().type = 3;
    }

    public void LD_Panel()
    {
        //Debug.Log("L_");
        Blade.getInstance().type = 4;
    }
}
